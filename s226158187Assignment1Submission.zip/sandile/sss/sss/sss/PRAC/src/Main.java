public class Main {
    public static void main(String[] args) {
        f polynomial=new f();
        polynomial.SetCoefficient(2,3);
        polynomial.SetCoefficient(1,5);
        System.out.println("THe first polynomial is:  "+ polynomial.Display());
        System.out.println("Evaluating at x=2 for polynomial 1:  "+ polynomial.Evaluate(2));

        f polynomial2=new f();
        polynomial2.SetCoefficient(2,-4);
        polynomial2.SetCoefficient(0,7);
        System.out.println("THe second polynomial is: "+ polynomial2.Display());

        f sumFunction=polynomial.Add(1,polynomial2);

        System.out.println("THe sum of the polynomial is: "+ sumFunction.Display());




        f head=new f();
        head.head=sumFunction.Derivative();
        System.out.println("THe derivative of the polynomial is: "+ sumFunction.Display());

        







    }


}

