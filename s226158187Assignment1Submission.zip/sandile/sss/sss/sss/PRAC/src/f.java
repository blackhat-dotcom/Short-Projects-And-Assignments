import java.util.IllegalFormatCodePointException;

public class f {
    f next;
    f head = null;
    double coefficient;
    int degree;

    public double Evaluate(int x) {
        f temp = head;
        double result = 0;
        while (temp != null) {
            result = result + temp.coefficient * Math.pow(x, temp.degree);
            temp = temp.next;
        }
        return result;

    }
    public f Derivative( ) {
        if(head == null) {
            return null;
        }
        else if(head.next == null) {
            if(head.degree == 0) {
                return null;
            }
            else{
                head.coefficient =head.coefficient*head.degree;
                head.degree = head.degree-1;
                return head;
            }
        }
        else{
            f prev=null;
            f temp = head;
            while(temp!=null)
            {
                if(temp.degree==0)
                {
                    if(prev==null)
                    {
                        head=head.next;
                        temp=null;

                    }
                    else {
                        prev.next=temp.next;
                        temp=null;
                    }

                }
                else{
                    prev=temp;
                    temp=temp.next;
                }

            }
            temp=head;
            while(temp!=null)
            {
                temp.coefficient =temp.coefficient*temp.degree;
                temp.degree = temp.degree-1;
                temp=temp.next;
            }
            return head;
        }

    }
    public String Display()
    {
        f temp = head;
        String s="";
        while(temp != null) {
           if(temp.degree!=0)
           {
               if(temp.degree == 1)
               {
                   if(temp.coefficient >= 0)
                   {
                       s=s+"+ "+temp.coefficient+"x^"+temp.degree  ;
                   }
                   else{
                       s=s+" "+temp.coefficient+"x^"+temp.degree;
                   }
               }
               else{
                   if(temp.coefficient >= 0)
                   {
                       s=s+"+ "+temp.coefficient+"x^"+temp.degree  ;
                   }
                   else{
                       s=s+" "+temp.coefficient+"x^"+temp.degree;
                   }

               }
           }
           else{
               if(temp.coefficient >= 0)
               {
                   s=s+"+ "+temp.coefficient;
               }
               else{
                   s=s+" "+temp.coefficient;
               }

           }
           temp = temp.next;

        }
        return s;
    }
    public f Add(int a, f newFunction){
        f newFunctionHead=newFunction.head;
        f sumFunction=new f();
        while(newFunctionHead!=null)
        {
            newFunctionHead.coefficient=newFunctionHead.coefficient*a;
            newFunctionHead=newFunctionHead.next;
        }
        f temp=newFunction.head;
        f temphead=head;
        while(temphead!=null && temp!=null)
        {
            if(temphead.degree==temp.degree)
            {
                double coefficientSS=temphead.coefficient+temp.coefficient;
                sumFunction.SetCoefficient(temphead.degree, coefficientSS);
                temphead=temphead.next;
                temp=temp.next;
            }
            else{
                if(temphead.degree>temp.degree)
                {
                    sumFunction.SetCoefficient(temphead.degree, temphead.coefficient);
                    temphead=temphead.next;

                }
                else{
                    sumFunction.SetCoefficient(temp.degree, temp.coefficient);
                    temp=temp.next;
                }
            }


        }
        if(temp!=null)
        {
            while(temp!=null)
            {
                sumFunction.SetCoefficient(temp.degree, temp.coefficient);
                temp=temp.next;
            }
        }
        if(temphead!=null)
        {
            while(temphead!=null)
            {
                sumFunction.SetCoefficient(temphead.degree, temphead.coefficient);
                temphead=temphead.next;
            }
        }
        return sumFunction;
    }
    public double GetCoefficient(int degree){
        double x=0;
        if (head != null) {
            f temp = head;
            while (temp != null) {
                if (temp.degree < degree) {
                    x = 0;
                    temp = null;
                } else if (temp.degree == degree) {
                    x = temp.coefficient;
                    temp = null;
                } else {
                    temp = temp.next;
                }
            }


        }
        return x;
    }

    public void SetCoefficient(int degree, double coefficient) {
        f newhead = new f();
        newhead.coefficient = coefficient;
        newhead.degree = degree;
        f prev = null;
        if (head == null) {
            head = newhead;
        } else {
            boolean inserted = false;
            f temp = head;
            if (head.next == null) {
                if (head.degree == degree) {
                    head.coefficient = coefficient;
                } else if (head.degree > degree) {
                    head.next = newhead;
                } else {
                    newhead.next = head;
                    head = newhead;
                }
            } else {
                while (!inserted) {
                    if (temp.degree == degree) {
                        temp.coefficient = coefficient;
                        inserted = true;
                    } else if (temp.degree > degree) {
                        if (temp.next == null) {
                            temp.next = newhead;
                            inserted = true;
                        } else {
                            prev = temp;
                            temp = temp.next;
                        }
                    } else {
                        if (prev == null) {
                            newhead.next = temp;
                            head = newhead;
                            inserted = true;
                        } else {
                            prev.next = newhead;
                            newhead.next = temp;
                            inserted = true;

                        }
                    }
                }
            }
        }
    }
}


