import java.util.LinkedList;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        LinkedList<String> directions = new LinkedList<>();
        Random rand = new Random();
        int[][] grid = new int[3][3];
        boolean[][] visited = new boolean[3][3];
        SetVisited(visited, 3, 3);
        CreateGrid(grid, rand);
        printGrid(grid);
        int p = findingPath(grid, 0, 0, 3, visited, directions, 0); // Adding pathLength
        if (p == 0) {
            System.out.println("No path has been found");
        } else {
            String S;
            String var10000;
            for(S = ""; !directions.isEmpty(); S = var10000 + " " + S) {
                var10000 = (String)directions.removeLast();
            }
            System.out.println("The path is " + S);
        }
    }

    public static void SetVisited(boolean[][] visited, int row, int col) {
        for(int i = 0; i < row; ++i) {
            for(int j = 0; j < col; ++j) {
                visited[i][j] = false;
            }
        }
    }

    public static void printGrid(int[][] grid) {
        for(int i = 0; i < grid.length; ++i) {
            for(int j = 0; j < grid[i].length; ++j) {
                System.out.print(grid[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void CreateGrid(int[][] grid, Random rand) {
        for(int i = 0; i < grid.length; ++i) {
            for(int j = 0; j < grid[i].length; ++j) {
                grid[i][j] = rand.nextInt(3) + 1;
            }
        }
    }

    public static boolean checkBounds(int row, int col, int max) {
        return row >= 0 && row < max && col >= 0 && col < max;
    }

    public static boolean checkRight(int row, int col, int max) {
        return row == max - 1 && col == max - 1;
    }

    public static int findingPath(int[][] grid, int row, int col, int max, boolean[][] visited, LinkedList<String> directions, int pathLength) {
        if (checkRight(row, col, max)) {
            System.out.println("Path Length: " + pathLength); // Print the length when the destination is reached
            return 1;
        } else if (checkBounds(row, col, max) && !visited[row][col]) {
            visited[row][col] = true;
            int currentValue = grid[row][col];

            // Right movement
            if (checkBounds(row, col + grid[row][col], max) && !visited[row][col + grid[row][col]]) {
                directions.add(currentValue + "R");
                if (findingPath(grid, row, col + grid[row][col], max, visited, directions, pathLength + 1) == 1) {
                    return 1;
                }
                directions.removeLast();
            }

            // Left movement
            if (checkBounds(row, col - grid[row][col], max) && !visited[row][col - grid[row][col]]) {
                directions.add(currentValue + "L");
                if (findingPath(grid, row, col - grid[row][col], max, visited, directions, pathLength + 1) == 1) {
                    return 1;
                }
                directions.removeLast();
            }

            // Down movement
            if (checkBounds(row + grid[row][col], col, max) && !visited[row + grid[row][col]][col]) {
                directions.add(currentValue + "D");
                if (findingPath(grid, row + grid[row][col], col, max, visited, directions, pathLength + 1) == 1) {
                    return 1;
                }
                directions.removeLast();
            }

            // Up movement
            if (checkBounds(row - grid[row][col], col, max) && !visited[row - grid[row][col]][col]) {
                directions.add(currentValue + "U");
                if (findingPath(grid, row - grid[row][col], col, max, visited, directions, pathLength + 1) == 1) {
                    return 1;
                }
                directions.removeLast();
            }

            return 0;
        } else {
            return 0;
        }
    }
}