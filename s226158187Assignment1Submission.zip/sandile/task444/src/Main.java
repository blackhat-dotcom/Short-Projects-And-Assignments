import java.util.LinkedList;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        System.out.println("Start of Task 2");
        for(int i=1;i<6;i++)
        {
            System.out.println("Example: "+ i);
            grid g=new grid();
            LinkedList<String> directions = new LinkedList<>();
            Random rand = new Random();
            int[][] grid = new int[3][3];
            boolean[][] visited = new boolean[3][3];
            g.SetVisited(visited, 3, 3);
            g.CreateGrid(grid, rand);
            g.printGrid(grid);
            int p = g.findingPath(grid, 0, 0, 3, visited, directions, 0); // Adding pathLength
            if (p == 0) {
                System.out.println("No path has been found");
            } else {
                String S;
                String var10000;
                for(S = ""; !directions.isEmpty(); S = var10000 + " " + S) {
                    var10000 = (String)directions.removeLast();
                }
                System.out.println("The path is " + S);
            }
            System.out.println();
        }
        System.out.println();
        System.out.println("End of Task 2");
        System.out.println();
        System.out.println("Start of Task 3");

        System.out.println("Example: 1");
        f polynomial=new f();
        polynomial.SetCoefficient(2,3);
        polynomial.SetCoefficient(1,5);
        System.out.println("The first polynomial is:  "+ polynomial.Display());
        System.out.println("Evaluating at x=2 for polynomial 1:  "+ polynomial.Evaluate(2));

        f polynomial2=new f();
        polynomial2.SetCoefficient(2,-4);
        polynomial2.SetCoefficient(0,7);
        System.out.println("The second polynomial is: "+ polynomial2.Display());

        f sumFunction=polynomial.Add(1,polynomial2);

        System.out.println("The sum of the polynomial is: "+ sumFunction.Display());
        System.out.println();



        f head=new f();
        head.head=sumFunction.Derivative();
        System.out.println("The derivative of the polynomial is: "+ sumFunction.Display());
        System.out.println();
        System.out.println("Example: 2");
        polynomial=new f();
        polynomial.SetCoefficient(2,9);
        polynomial.SetCoefficient(4,1);
        System.out.println("The first polynomial is:  "+ polynomial.Display());
        System.out.println("Evaluating at x=2 for polynomial 1:  "+ polynomial.Evaluate(2));

        polynomial2=new f();
        polynomial2.SetCoefficient(3,8);
        polynomial2.SetCoefficient(2,3);
        System.out.println("The second polynomial is: "+ polynomial2.Display());

         sumFunction=polynomial.Add(1,polynomial2);

        System.out.println("The sum of the polynomial is: "+ sumFunction.Display());
        System.out.println();



        head=new f();
        head.head=sumFunction.Derivative();
        System.out.println("The derivative of the polynomial is: "+ sumFunction.Display());
        System.out.println();
        System.out.println("Example: 3");
        polynomial=new f();
        polynomial.SetCoefficient(3,9);
        polynomial.SetCoefficient(2,5);
        System.out.println("The first polynomial is:  "+ polynomial.Display());
        System.out.println("Evaluating at x=2 for polynomial 1:  "+ polynomial.Evaluate(2));

        polynomial2=new f();
        polynomial2.SetCoefficient(1,2);
        polynomial2.SetCoefficient(4,5);
        System.out.println("The second polynomial is: "+ polynomial2.Display());

        sumFunction=polynomial.Add(3,polynomial2);

        System.out.println("The sum of the polynomial is: "+ sumFunction.Display());
        System.out.println();



        head=new f();
        head.head=sumFunction.Derivative();
        System.out.println("The derivative of the polynomial is: "+ sumFunction.Display());
        System.out.println();
        System.out.println("Example: 4");
        polynomial=new f();
        polynomial.SetCoefficient(4,95);
        polynomial.SetCoefficient(5,2);
        System.out.println("The first polynomial is:  "+ polynomial.Display());
        System.out.println("Evaluating at x=2 for polynomial 1:  "+ polynomial.Evaluate(2));

        polynomial2=new f();
        polynomial2.SetCoefficient(1,2);
        polynomial2.SetCoefficient(0,7);
        System.out.println("The second polynomial is: "+ polynomial2.Display());

        sumFunction=polynomial.Add(3,polynomial2);

        System.out.println("The sum of the polynomial is: "+ sumFunction.Display());
        System.out.println();



        head=new f();
        head.head=sumFunction.Derivative();
        System.out.println("The derivative of the polynomial is: "+ sumFunction.Display());
        System.out.println();

        System.out.println("Example: 5");
        polynomial=new f();
        polynomial.SetCoefficient(3,90);
        polynomial.SetCoefficient(7,21);
        System.out.println("The first polynomial is:  "+ polynomial.Display());
        System.out.println("Evaluating at x=2 for polynomial 1:  "+ polynomial.Evaluate(2));

        polynomial2=new f();
        polynomial2.SetCoefficient(6,8);
        polynomial2.SetCoefficient(3,-27);
        System.out.println("The second polynomial is: "+ polynomial2.Display());

        sumFunction=polynomial.Add(5,polynomial2);

        System.out.println("The sum of the polynomial is: "+ sumFunction.Display());
        System.out.println();



        head=new f();
        head.head=sumFunction.Derivative();
        System.out.println("The derivative of the polynomial is: "+ sumFunction.Display());
        System.out.println();


    }
}