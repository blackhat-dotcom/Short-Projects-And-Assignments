import java.util.ArrayList;
import java.util.List;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers=new ArrayList<>();
        Scanner inn=new Scanner(System.in);
        Menu menu=new Menu("Main Menu");
        menu.addChoice(new MenuChoice() {
            @Override
            public String getText() {
                return "Add a number";
            }

            @Override
            public void run() {

            System.out.println("Enter a number: ");
            try {
                int number=inn.nextInt();
                numbers.add(number);
            } catch (InputMismatchException e) {
                System.out.println("Input is invalid.Please try a valid number");
                inn.nextLine();

            }
            }
        });
        menu.addChoice(new MenuChoice() {
            @Override
            public String getText() {
                return "Display";
            }

            @Override
            public void run() {
                System.out.println("Displaying numbers: ");
                if(numbers.isEmpty()){
                    System.out.println("List is empty.");
                }
                for(int numbX: numbers)
                {
                    System.out.print(numbX+" ");
                }
            }
        });
        menu.addChoice(new MenuChoice() {
            @Override
            public String getText() {
                return "Clear";
            }

            @Override
            public void run() {
                numbers.clear();
                System.out.println("List is cleared");
            }
        });
        Menu displayOptions=new Menu("Display Options");
        displayOptions.addChoice(new MenuChoice() {
            @Override
            public String getText() {
                return "Mean";
            }

            @Override
            public void run() {
                if (numbers.isEmpty()) {
                    System.out.println("No numbers available to calculate mean.");
                } else {
                    double sum=0;
                    for (int num: numbers) {
                        sum+=num;
                    }
                    double mean=sum/numbers.size();
                    System.out.println("Mean of the numbers: " + mean);
                }
            }
        });
        displayOptions.addChoice(new MenuChoice() {
            @Override
            public String getText() {
                return "Prime numbers";
            }

            @Override
            public void run() {
            if(numbers.isEmpty()){
                System.out.println("Prime numbers cannot be found");
            }
            else{
                boolean foundPrimes=false;
                for(int numberX: numbers){
                    if(isPrime(numberX)==true){
                        System.out.print(numberX+" ");
                        foundPrimes=true;
                    }
                }
                if(foundPrimes==false){
                    System.out.println("No primes were found! ");
                }
                }
            }
        });
        menu.addChoice(displayOptions);
        
        menu.run();
        inn.close();




    }
    public static boolean isPrime(int number){

        for(int i=2;i<number;i++){
            if(number%i==0)

                return false;
        }
        return true;

    }
}