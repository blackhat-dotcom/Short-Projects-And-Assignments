public interface MenuChoice {

    public String getText();
    public  void run();

}
