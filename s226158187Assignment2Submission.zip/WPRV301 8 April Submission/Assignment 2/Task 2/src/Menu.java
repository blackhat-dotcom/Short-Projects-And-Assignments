import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu implements MenuChoice {
    private List<MenuChoice> list = new ArrayList<>();
    private String title = "";

    public Menu(String title) {
        this.title = title;
    }

    @Override
    public String getText() {
        return title;
    }

    @Override
    public void run() {
        Scanner inn = new Scanner(System.in);
        boolean done = false;
        while (!done) {
            System.out.println("\n" + title + ":");
            for (int i = 0; i < list.size(); i++) {
                System.out.println((i + 1) + ". " + list.get(i).getText());
            }
            System.out.println((list.size() + 1) + ". Exit"); 

            int choice = -1;
            while (true) {
                System.out.print("Enter wanted option: ");
                if (inn.hasNextInt()) {
                    choice = inn.nextInt();
                    inn.nextLine();
                    if (choice >= 1 && choice <= list.size() + 1) {
                        break;
                    }
                } else {
                    inn.nextLine();
                }
                System.out.println("Invalid choice! Please enter a valid number.");
            }

            if (choice >= 1 && choice <= list.size()) {
                list.get(choice - 1).run(); //
            } else if (choice == list.size() + 1) {
                done = true; //
            }
        }
    }

    public void addChoice(MenuChoice tMenuChoice) {
        list.add(tMenuChoice);
    }

    protected void DisplayChoices() {
        System.out.println(title);
        int i = 1;
        for (MenuChoice x : list) {
            System.out.println("Option: " + i + " " + x.getText());
            i++;
        }
    }
}