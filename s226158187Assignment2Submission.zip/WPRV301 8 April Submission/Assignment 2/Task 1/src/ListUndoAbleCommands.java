import java.util.List;

public class ListUndoAbleCommands implements UndoableCommands {
    List<String> list;
    public ListUndoAbleCommands(List<String> newList){
        list=newList;
    }
    @Override
    public void doIt() {
    }

    @Override
    public void UndoIt() {
    }

}
