interface UndoableCommands {
    void doIt();
    void UndoIt();

}
