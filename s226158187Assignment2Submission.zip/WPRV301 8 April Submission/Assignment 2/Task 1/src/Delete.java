import java.io.PrintStream;
import java.util.List;
import java.util.Stack;

public class Delete extends ListUndoAbleCommands {
    int index;
    String addValue;
    int count;
    Stack<Integer> undoIndexes = new Stack();
    Stack<String> undoAddedValues = new Stack();
    Stack<Integer> redoIndexes = new Stack();
    Stack<String> redoAddedValues = new Stack();

    public Delete(List<String> newList, int index) {
        super(newList);
        this.index = index;
        this.addValue = (String)this.list.get(index);
        this.count = 0;
    }

    public void doIt() {
        if ((this.index >= 0 && this.index < this.list.size() || this.index == 0) && this.count == 0) {
            this.undoIndexes.add(this.index);
            this.undoAddedValues.add(this.addValue);
            this.list.remove(this.index);
            this.count = 1;
            PrintStream var10000 = System.out;
            String var10001 = (String)this.undoAddedValues.peek();
            var10000.println("The undo stack: " + var10001 + " " + String.valueOf(this.undoIndexes.peek()));
            System.out.println("The redo stack:   ");
        }

    }

    public void UndoIt() {
        if (this.count == 1) {
            this.list.add(this.index, this.addValue);
            this.redoAddedValues.add((String)this.undoAddedValues.pop());
            this.redoIndexes.add((Integer)this.undoIndexes.pop());
            --this.count;
            System.out.println("The undo stack:   ");
            PrintStream var10000 = System.out;
            String var10001 = (String)this.redoAddedValues.peek();
            var10000.println("The redo stack: " + var10001 + " " + String.valueOf(this.redoIndexes.peek()));
        }

    }

    public void RedoIt() {
        if (this.count == 0) {
            this.doIt();
        }
    }
}