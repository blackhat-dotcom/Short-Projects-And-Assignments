import java.io.PrintStream;
import java.util.List;
import java.util.Stack;

public class Insert extends ListUndoAbleCommands {
    String addValue;
    int index;
    int count;
    Stack<Integer> undoIndexes = new Stack();
    Stack<String> undoAddedValues = new Stack();
    Stack<Integer> redoIndexes = new Stack();
    Stack<String> redoAddedValues = new Stack();

    public Insert(List<String> newList, int index, Object value) {
        super(newList);
        this.index = index;
        this.addValue = value.toString();
        this.count = 0;
    }

    public void doIt() {
        if (this.count == 0) {
            if (this.index == 0) {
                this.list.add(this.index, this.addValue);
                this.undoIndexes.add(this.index);
                this.undoAddedValues.add(this.addValue);
                ++this.count;
                PrintStream var10000 = System.out;
                String var10001 = (String)this.undoAddedValues.peek();
                var10000.println("The undo stack: " + var10001 + " " + String.valueOf(this.undoIndexes.peek()));
                System.out.println("The redo stack:   ");
            } else if (this.index >= 0 && this.index < this.list.size()) {
                this.list.add(this.index, this.addValue);
                this.undoIndexes.add(this.index);
                this.undoAddedValues.add(this.addValue);
                ++this.count;
                PrintStream var1 = System.out;
                String var2 = (String)this.undoAddedValues.peek();
                var1.println("The undo stack: " + var2 + " " + String.valueOf(this.undoIndexes.peek()));
                System.out.println("The redo stack:   ");
            }
        }

    }

    public void UndoIt() {
        if (!this.list.isEmpty() && this.count == 1) {
            this.list.remove(this.index);
            this.redoAddedValues.add((String)this.undoAddedValues.pop());
            this.redoIndexes.add((Integer)this.undoIndexes.pop());
            System.out.println("The undo stack:   ");
            PrintStream var10000 = System.out;
            String var10001 = (String)this.redoAddedValues.peek();
            var10000.println("The redo stack: " + var10001 + " " + String.valueOf(this.redoIndexes.peek()));
        }

    }

    public void RedoIt() {
        if (this.count == 0) {
            this.doIt();
        }
    }
}