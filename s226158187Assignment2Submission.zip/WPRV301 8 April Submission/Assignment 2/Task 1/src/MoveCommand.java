import java.util.List;
import java.util.Stack;

public class MoveCommand extends ListUndoAbleCommands {
    int start;
    int end;
    String value1;
    String value2;
    int count;
    Stack<Integer> undoIndexes = new Stack();
    Stack<String> undoAddedValues = new Stack();
    Stack<Integer> redoIndexes = new Stack();
    Stack<String> redoAddedValues = new Stack();

    public MoveCommand(List<String> list, int fromIndex, int toIndex) {
        super(list);
        this.start = fromIndex;
        this.end = toIndex;
        this.count = 0;
    }

    public void doIt() {
        if (this.count == 0 && this.CheckBounds(this.start, this.end)) {
            this.value1 = (String)this.list.get(this.start);
            this.value2 = (String)this.list.get(this.end);
            this.list.set(this.start, this.value2);
            this.list.set(this.end, this.value1);
            this.undoIndexes.add(this.start);
            this.undoAddedValues.add(this.value1);
            this.undoIndexes.add(this.end);
            this.undoAddedValues.add(this.value2);
            System.out.println("The undo stack: " + this.value1 + " " + this.start);
            System.out.println("                " + this.value2 + " " + this.end);
            System.out.println("The redo stack:   ");
            ++this.count;
        }

    }

    public boolean CheckBounds(int start, int end) {
        return start >= 0 && start < this.list.size() && end >= 0 && end < this.list.size();
    }

    public void UndoIt() {
        if (this.count == 1) {
            this.value1 = (String)this.list.get(this.start);
            this.value2 = (String)this.list.get(this.end);
            this.list.set(this.start, this.value2);
            this.list.set(this.end, this.value1);
            this.redoAddedValues.add((String)this.undoAddedValues.pop());
            this.redoIndexes.add((Integer)this.undoIndexes.pop());
            this.redoAddedValues.add((String)this.undoAddedValues.pop());
            this.redoIndexes.add((Integer)this.undoIndexes.pop());
            --this.count;
            System.out.println("The undo stack:    ");
            System.out.println("The redo stack:   " + this.value1 + " " + this.start);
            System.out.println("                " + this.value2 + " " + this.end);
            --this.count;
        }

    }

    public void RedoIt() {
        if (this.count == 0) {
            this.doIt();
        }
    }
}