import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        ListUndoAbleCommands command = null;
        Scanner scanner = new Scanner(System.in);
        int option;

        while (true) {
            System.out.println("\n=== Menu ===");
            System.out.println("1. Insert");
            System.out.println("2. Delete");
            System.out.println("3. Move");
            System.out.println("4. Undo");
            System.out.println("5. Redo");
            System.out.println("6. Display List");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    System.out.print("Enter value to insert: ");
                    String insertValue = scanner.nextLine();
                    System.out.print("Enter index to insert at: ");
                    int insertIndex = scanner.nextInt();
                    command = new Insert(list, insertIndex, insertValue);
                    System.out.println("Choose action: 1 for Do, 2 for Undo");
                    int insertChoice = scanner.nextInt();
                    if (insertChoice == 1) {
                        command.doIt();
                    } else if (insertChoice == 2) {
                        command.UndoIt();
                    }
                    break;

                case 2:
                    System.out.print("Enter index to delete: ");
                    int deleteIndex = scanner.nextInt();
                    command = new Delete(list, deleteIndex);
                    System.out.println("Choose action: 1 for Do, 2 for Undo");
                    int deleteChoice = scanner.nextInt();
                    if (deleteChoice == 1) {
                        command.doIt();
                    } else if (deleteChoice == 2) {
                        command.UndoIt();
                    }
                    break;

                case 3:
                    System.out.print("Enter start index: ");
                    int startIndex = scanner.nextInt();
                    System.out.print("Enter end index: ");
                    int endIndex = scanner.nextInt();
                    command = new MoveCommand(list, startIndex, endIndex);
                    System.out.println("Choose action: 1 for Do, 2 for Undo");
                    int moveChoice = scanner.nextInt();
                    if (moveChoice == 1) {
                        command.doIt();
                    } else if (moveChoice == 2) {
                        command.UndoIt();
                    }
                    break;

                case 4:
                    if (command != null) {
                        command.UndoIt();
                    } else {
                        System.out.println("No action to undo.");
                    }
                    break;

                case 5:
                    if (command != null) {
                        if (command instanceof MoveCommand) {
                            ((MoveCommand) command).RedoIt();
                        } else if (command instanceof Insert) {
                            ((Insert) command).RedoIt();
                        } else if (command instanceof Delete) {
                            ((Delete) command).RedoIt();
                        }
                    } else {
                        System.out.println("No action to redo.");
                    }
                    break;

                case 6:
                    System.out.println("\nCurrent List: " + list);
                    break;

                case 7:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}