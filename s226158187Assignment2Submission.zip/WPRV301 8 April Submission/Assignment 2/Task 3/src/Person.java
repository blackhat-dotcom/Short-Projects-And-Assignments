public class Person {
    public Property<String> name;

    public Person(){
        name=new Property<>(this,"");
    }

}
