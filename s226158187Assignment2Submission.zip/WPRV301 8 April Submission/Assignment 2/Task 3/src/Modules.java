import java.util.ArrayList;
import java.util.List;

public class Modules {
    private Student student;
    private String moduleName;
    private List<Assessment> assessments;

    public Modules(Student student, String moduleName) {
        this.student = student;
        this.moduleName = moduleName;
        this.assessments = new ArrayList<>();
    }

    // Add assessment and recalculate module average
    public void addAssessment(Assessment assessment) {
        assessments.add(assessment);
        updateAverage();
    }

    // Recalculate module average based on assessments
    public void updateAverage() {
        double total = 0.0;
        for (Assessment assessment : assessments) {
            total += assessment.getGrade();
        }
        double average = assessments.isEmpty() ? 0.0 : total / assessments.size();
        System.out.println("Module " + moduleName + " average changed to: " + average);
        student.updateAverage();  // Update student's average after module average change
    }

    // Calculate the average of assessments for the module
    public double calculateAverage() {
        double total = 0.0;
        for (Assessment assessment : assessments) {
            total += assessment.getGrade();
        }
        return assessments.isEmpty() ? 0.0 : total / assessments.size();
    }

    public String getModuleName() {
        return moduleName;
    }

    public List<Assessment> getAssessments() {
        return assessments;
    }
}




