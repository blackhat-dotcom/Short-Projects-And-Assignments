import java.util.ArrayList;
import java.util.List;

public class Student{
    private String name;
    private List<Modules> modules;

    public Student(String name) {
        this.name = name;
        this.modules = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void addModule(Modules module) {
        modules.add(module);
    }

    public List<Modules> getModules() {
        return modules;
    }

    public void updateAverage() {
        double totalAverage = 0.0;
        for (Modules module : modules) {
            totalAverage += module.calculateAverage();
        }
        double studentAverage = modules.isEmpty() ? 0.0 : totalAverage / modules.size();
        System.out.println("Student average updated to: " + studentAverage);
    }

}



