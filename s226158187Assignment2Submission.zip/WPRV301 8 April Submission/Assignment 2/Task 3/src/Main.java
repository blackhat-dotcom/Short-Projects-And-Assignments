public class Main {
    public static void main(String[] args) {

        Student s = new Student("Sandile");

        Modules wra301 = new Modules(s, "WRA301");
        Modules wrd301 = new Modules(s, "WRD301");


        s.addModule(wra301);
        s.addModule(wrd301);

        Assessment a1 = new Assessment(wra301, 80);
        Assessment a2 = new Assessment(wra301, 70);
        Assessment a3 = new Assessment(wrd301, 90);
        Assessment a4 = new Assessment(wrd301, 60);

        wra301.addAssessment(a1);
        wra301.addAssessment(a2);
        wrd301.addAssessment(a3);
        wrd301.addAssessment(a4);

        a1.setGrade(100);

        System.out.println("Grades for student: " + s.getName());
        for (Modules module : s.getModules()) {
            System.out.println("Module: " + module.getModuleName());
            for (Assessment assessment : module.getAssessments()) {
                System.out.println("  Assessment Score: " + assessment.getScore() + ", Grade: " + assessment.getGrade());
            }
        }
    }
}






