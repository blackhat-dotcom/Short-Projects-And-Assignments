public class Assessment {

        private Modules module;
        private int score;
        private int grade;

        public Assessment(Modules module, int score) {
            this.module = module;
            this.score = score;
            this.grade = score;
        }

        public void setGrade(int grade) {
            if (this.grade != grade) {
                System.out.println("Assessment " + module.getModuleName() + " grade changed from " + this.grade + " to " + grade);
                this.grade = grade;
                module.updateAverage();
            }
        }

        public int getGrade() {
            return grade;
        }

        public int getScore() {
            return score;
        }
}