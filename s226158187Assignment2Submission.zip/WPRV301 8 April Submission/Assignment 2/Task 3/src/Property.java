import java.util.ArrayList;
import java.util.List;

public class Property<T>  {
    T value;
    List<PropertyListener<T>> listenerList=new ArrayList<>();
    Object owner;
    public Property(Object owner, T initialValue){
        value=initialValue;
        this.owner=owner;
    }
    public Object getOwner(){
        return owner;
    }
    public T get(){
        return  value;
    }
    public void set(T newValue){
        T oldValue=value;
        value=newValue;
        notifyListeners(oldValue,value);

    }
    public void addListener(PropertyListener<T> listener){
        listenerList.add(listener);
    }
    public void removeListener(PropertyListener<T> listener){
        listenerList.remove(listener);
    }
    protected void notifyListeners(T oldValue,T newValue){
        if(!listenerList.isEmpty()){
            for(PropertyListener<T> x: listenerList){
                x.valueChanged(this,oldValue,newValue);
            }
        }
    }

}
