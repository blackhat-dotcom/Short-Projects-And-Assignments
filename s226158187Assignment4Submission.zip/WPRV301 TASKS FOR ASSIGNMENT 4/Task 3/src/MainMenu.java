import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;

public class MainMenu {

    public StackPane create() {
        StackPane layout = new StackPane();
        VBox menu = new VBox(20);
        menu.setAlignment(Pos.CENTER);

        Label title = new Label("🐾 Boop Game 🐾");
        Button playButton = new Button("Start Game");
        Button bonusButton = new Button("What's New?");

        playButton.setOnAction(e -> {
            GameScreen game = new GameScreen();
            Scene gameScene = new Scene(game.create(), 800, 600);
            Main.window.setScene(gameScene);
        });

        bonusButton.setOnAction(e -> showBonusPopup());

        menu.getChildren().addAll(title, playButton, bonusButton);
        layout.getChildren().add(menu);
        return layout;
    }

    private void showBonusPopup() {
        Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        popup.setTitle("Bonus Features");

        VBox box = new VBox(15);
        box.setAlignment(Pos.CENTER);
        box.setStyle("-fx-padding: 20;");

        String[] lines = {
                "Bonus Features Included:",
                "- Boop and drag sound effects",
                "- Animated cat bounce",
                "- Ambient moths in background",
                "- Pop-up bonus description",
                "- Cursor changes, shadows"
        };

        for (String line : lines) {
            box.getChildren().add(new Text(line));
        }

        Button close = new Button("Close");
        close.setOnAction(e -> popup.close());
        box.getChildren().add(close);

        Scene scene = new Scene(box, 400, 300);
        popup.setScene(scene);
        popup.showAndWait();
    }
}