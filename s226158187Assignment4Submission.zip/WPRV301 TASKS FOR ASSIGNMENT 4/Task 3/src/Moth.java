import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.util.Random;

public class Moth {
    Circle circle;
    double speed;

    public Moth() {
        Random rand = new Random();
        circle = new Circle(3, Color.LIGHTGRAY);
        circle.setCenterX(rand.nextInt(800));
        circle.setCenterY(rand.nextInt(300));
        speed = 0.5 + rand.nextDouble();
    }

    public void update() {
        circle.setCenterY(circle.getCenterY() + speed);
        if (circle.getCenterY() > 600) {
            circle.setCenterY(0);
            circle.setCenterX(new Random().nextInt(800));
        }
    }

    public Circle getNode() {
        return circle;
    }
}