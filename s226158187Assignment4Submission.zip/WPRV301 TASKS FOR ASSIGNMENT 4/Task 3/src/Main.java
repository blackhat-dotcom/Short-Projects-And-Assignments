import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static Stage window;

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        MainMenu mainMenu = new MainMenu();
        Scene mainScene = new Scene(mainMenu.create(), 800, 600);

        window.setTitle("Boop Game - JavaFX");
        window.setScene(mainScene);
        window.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}