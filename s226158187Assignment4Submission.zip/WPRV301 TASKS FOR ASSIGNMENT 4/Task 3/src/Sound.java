import javafx.scene.media.AudioClip;

public class Sound {
    public static void play(String filename) {
        AudioClip sound = new AudioClip(Sound.class.getResource("/boop.mp3").toString());
        sound.play();
    }
}