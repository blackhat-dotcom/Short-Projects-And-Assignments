import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Cat {
    ImageView image;
    double offsetX, offsetY;

    public Cat(String path, double x, double y) {
        Image catImg = new Image(path);
        image = new ImageView(catImg);
        image.setFitWidth(80);
        image.setFitHeight(80);
        image.setX(x);
        image.setY(y);

        image.setOnMousePressed(e -> {
            offsetX = e.getSceneX() - image.getX();
            offsetY = e.getSceneY() - image.getY();
            Sound.play("drag.mp3");
        });

        image.setOnMouseDragged(e -> {
            image.setX(e.getSceneX() - offsetX);
            image.setY(e.getSceneY() - offsetY);
        });

        image.setOnMouseReleased(e -> {
            Sound.play("boop.mp3");
        });
    }

    public ImageView getNode() {
        return image;
    }
}
