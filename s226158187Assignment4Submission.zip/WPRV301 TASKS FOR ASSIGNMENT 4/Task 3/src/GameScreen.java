import javafx.animation.AnimationTimer;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.util.ArrayList;

public class GameScreen {
    private ArrayList<Moth> moths = new ArrayList<>();

    public Pane create() {
        Pane root = new Pane();

        // Ambient sound
        Media ambient = new Media(getClass().getResource("/ambient.mp3").toString());
        MediaPlayer player = new MediaPlayer(ambient);
        player.setCycleCount(MediaPlayer.INDEFINITE);
        player.play();

        // Create moths
        for (int i = 0; i < 10; i++) {
            Moth moth = new Moth();
            moths.add(moth);
            root.getChildren().add(moth.getNode());
        }

        // Add cat
        Cat cat = new Cat("/cat.png", 200, 300);
        root.getChildren().add(cat.getNode());

        // Animate moths
        AnimationTimer timer = new AnimationTimer() {
            public void handle(long now) {
                moths.forEach(Moth::update);
            }
        };
        timer.start();

        return root;
    }
}