import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.Objects;


public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Label lblName=new Label("Name:");
        TextField txtName=new TextField();

        Label lblSurname=new Label("Surname:");
        TextField txtSurname=new TextField();

        Label lblStudentNumber=new Label("Student Number");
        TextField txtStudentNumber=new TextField();

        Label lblCourse=new Label("Course:");
        TextField txtCourse=new TextField();

        Label lblYear=new Label("Year:");
        TextField txtYear=new TextField();

        Button OK=new Button("OK");
        Button Cancel=new Button("Cancel");


        GridPane grid=new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        grid.add(lblName,0,0);
        grid.add(txtName,1,0);
        grid.add(lblSurname,0,1);
        grid.add(txtSurname,1,1);
        grid.add(lblStudentNumber,0,2);
        grid.add(txtStudentNumber,1,2);
        grid.add(lblCourse,0,3);
        grid.add(txtCourse,1,3);
        grid.add(lblYear,0,4);
        grid.add(txtYear,1,4);
        HBox h=new HBox(10);
        h.getChildren().addAll(OK,Cancel);
        h.setAlignment(Pos.CENTER_RIGHT);
        grid.add(h,0,5,2,   1);






        // Printer label
        Label lblPrinter = new Label("Printer: Epson EPL-700");

        // Radio buttons and toggle group
        RadioButton rbnImage = new RadioButton("Image");
        RadioButton rbnText = new RadioButton("Text");
        RadioButton rbnCode = new RadioButton("Code");

        ToggleGroup formatGroup = new ToggleGroup();
        rbnImage.setToggleGroup(formatGroup);
        rbnText.setToggleGroup(formatGroup);
        rbnCode.setToggleGroup(formatGroup);

        HBox radioBox = new HBox(15, rbnImage, rbnCode, rbnText);
        radioBox.setAlignment(Pos.CENTER_LEFT);

        // Print quality label and checkbox
        Label lblPrintQuality = new Label("Print Quality");
        CheckBox checkBox = new CheckBox("Print to file");

        // Action buttons
        Button OK1 = new Button("OK");
        Button Cancel1 = new Button("Cancel");
        Button Help = new Button("Help");
        Button SetUp = new Button("SetUp");

        FlowPane buttons = new FlowPane(10, 10, OK1, Cancel1, SetUp, Help);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        // Grid layout
        GridPane grid2 = new GridPane();
        grid2.setHgap(10);
        grid2.setVgap(15);
        grid2.setPadding(new Insets(20));

        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(50);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(50);
        grid2.getColumnConstraints().addAll(col1, col2);

        grid2.add(lblPrinter, 0, 0, 2, 1);
        grid2.add(radioBox, 0, 1, 2, 1);
        grid2.add(lblPrintQuality, 0, 2);
        grid2.add(checkBox, 1, 2);
        grid2.add(buttons, 0, 3, 2, 1);

        // Labels for the "View", "Edit", "Help"
        Label lblView = new Label("View");
        Label lblEdit = new Label("Edit");
        Label lblHelp = new Label("Help");

// TextField for input
        TextField txtInsert = new TextField();
        txtInsert.setMaxWidth(240);
        txtInsert.setMaxHeight(12);

// HBox to contain the labels
        HBox viewBox = new HBox(10); // 10 is the space between labels
        viewBox.setAlignment(Pos.CENTER_LEFT);
        viewBox.setMaxWidth(240);
        viewBox.setMaxHeight(12);
        viewBox.getChildren().addAll(lblView, lblEdit, lblHelp);

// VBox to hold the HBox and TextField
        VBox BOX = new VBox(10); // 10 is the space between the HBox and TextField
        BOX.setAlignment(Pos.CENTER_LEFT);

// Adding margin to the TextField for more space between label and TextField
        VBox.setMargin(txtInsert, new Insets(10, 0, 0, 0)); // Adds 10px margin on top of TextField

// Adding both the HBox and TextField to the VBox
        BOX.getChildren().addAll(viewBox, txtInsert);

// Add the VBox to a Grid or another container as needed
        GridPane grid3=new GridPane();
        grid3.setHgap(10);
        grid3.setVgap(10);
        grid3.setPadding(new Insets(20));
        grid3.add(BOX, 0, 0, 5, 1);
        Button buttonMC=new Button(" MC ");
        Button buttonMR=new Button(" MR ");
        Button buttonMS=new Button(" MS ");
        Button buttonMa=new Button(" M+ ");
        Button buttonMm=new Button(" M- ");
        Button[] allButtons={buttonMC,buttonMR,buttonMS, buttonMa,buttonMm };
        for (Button btn : allButtons) {
            btn.setPrefWidth(60);
            btn.setPrefHeight(40);
        }

        grid3.add(buttonMC,0,2);
        grid3.add(buttonMR,1,2);
        grid3.add(buttonMS,2,2);
        grid3.add(buttonMa,3,2);
        grid3.add(buttonMm,4,2);

        Button buttonArrow=new Button(" <- ");
        Button buttonCE=new Button(" CE ");
        Button buttonC=new Button(" C ");
        Button buttonPm=new Button(" + or - ");
        Button buttonRoot=new Button(" Sqrt ");

        Button[] allButtons1={buttonArrow,buttonCE,buttonC, buttonPm,buttonRoot };
        for (Button btn : allButtons1) {
            btn.setPrefWidth(60);
            btn.setPrefHeight(40);
        }

        grid3.add(buttonArrow,0,3);
        grid3.add(buttonCE,1,3);
        grid3.add(buttonC,2,3);
        grid3.add(buttonPm,3,3);
        grid3.add(buttonRoot,4,3);


        Button buttonSeven=new Button(" 7 ");
        Button buttonEight=new Button(" 8 ");
        Button buttonNine=new Button(" 9 ");
        Button buttonDivide=new Button("/");
        Button buttonPercentage=new Button(" % ");

        Button[] allButtons2={buttonSeven,buttonEight,buttonNine, buttonDivide,buttonPercentage };
        for (Button btn : allButtons2) {
            btn.setPrefWidth(60);
            btn.setPrefHeight(40);
        }

        grid3.add(buttonSeven,0,4);
        grid3.add(buttonEight,1,4);
        grid3.add(buttonNine,2,4);
        grid3.add(buttonDivide,3,4);
        grid3.add(buttonPercentage,4,4);


        Button buttonFour=new Button(" 4 ");
        Button buttonFive=new Button(" 5 ");
        Button buttonSix=new Button(" 6 ");
        Button buttonMultiply=new Button(" * ");
        Button buttonInverse=new Button(" 1/x ");

        Button[] allButtons3={buttonFour,buttonFive,buttonSix, buttonMultiply,buttonInverse };
        for (Button btn : allButtons3) {
            btn.setPrefWidth(60);
            btn.setPrefHeight(40);
        }

        grid3.add(buttonFour,0,5);
        grid3.add(buttonFive,1,5);
        grid3.add(buttonSix,2,5);
        grid3.add(buttonMultiply,3,5);
        grid3.add(buttonInverse,4,5);

        Button buttonOne=new Button(" 1 ");
        Button buttonTwo=new Button(" 2 ");
        Button buttonThree=new Button(" 3 ");
        Button buttonMinus=new Button(" - ");
        Button buttonEquals=new Button(" = ");

        Button[] allButtons4={buttonOne,buttonTwo,buttonThree, buttonMinus,buttonEquals };
        for (Button btn : allButtons4) {
            if(!Objects.equals(btn.getText(), buttonEquals.getText())){
                btn.setMaxWidth(60);
                btn.setPrefHeight(180);
            }
            else{
                btn.setPrefWidth(60);
                btn.setPrefHeight(40);
            }
        }

        grid3.add(buttonOne,0,6);
        grid3.add(buttonTwo,1,6);
        grid3.add(buttonThree,2,6);
        grid3.add(buttonMinus,3,6);
        grid3.add(buttonEquals,4,6,1,2);

        Button buttonZero=new Button(" 0 ");
        Button buttonDecimal=new Button(" . ");
        Button buttonPlus=new Button(" + ");

        Button[] allButtons5={buttonZero,buttonDecimal,buttonPlus };
        for (Button btn : allButtons5) {
            if(!Objects.equals(btn.getText(), buttonZero.getText())){
                btn.setMaxWidth(150);
                btn.setPrefHeight(60);
            }
            else{
                btn.setPrefWidth(100);
                btn.setPrefHeight(40);
            }

        }

        grid3.add(buttonZero,0,7,2,1);
        grid3.add(buttonDecimal,2,7);
        grid3.add(buttonPlus,3,7);











        TabPane tabPane = new TabPane();
        Tab studentTab = new Tab("Student Info", grid);
        Tab printerTab = new Tab("Printer Settings", grid2);
        Tab calculatorTab =new Tab("Calculator",grid3);
        studentTab.setClosable(false);
        printerTab.setClosable(false);
        calculatorTab.setClosable(false);
        tabPane.getTabs().addAll(studentTab, printerTab,calculatorTab);

        // ----------------- Scene Setup -----------------
        Scene scene = new Scene(tabPane, 500, 350);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Multi-Form Application");
        primaryStage.show();
    }
}