public class Song {
    private int songId;
    private String title;
    private String artist;
    private int songNo;  // Song number in the album (track number)
    private int length;  // Length of the song in seconds

    // Constructor
    public Song(int songId, String title, String artist, int songNo, int length) {
        this.songId = songId;
        this.title = title;
        this.artist = artist;
        this.songNo = songNo;
        this.length = length;
    }

    // Getters and setters (if needed)
    public int getSongId() {
        return songId;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public int getSongNo() {
        return songNo;
    }

    public int getLength() {
        return length;
    }

    @Override
    public String toString() {
        return title + " by " + artist; // Custom display format
    }
}