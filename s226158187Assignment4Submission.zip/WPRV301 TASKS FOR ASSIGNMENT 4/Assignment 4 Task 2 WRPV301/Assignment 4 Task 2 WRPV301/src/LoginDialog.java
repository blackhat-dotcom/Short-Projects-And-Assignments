import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.VBox;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import javafx.stage.Modality;
import java.sql.*;

public class LoginDialog {
    // Create a variable for connection
    static Connection conn = null;
    public static Connection showLoginDialog() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Login");

        VBox vbox = new VBox(10);
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        javafx.scene.control.Button loginButton = new javafx.scene.control.Button("Login");



        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            conn = connectToDatabase(username, password);
            if (conn != null) {
                dialog.close();
            } else {
                showAlert("Error", "Connection failed. Please check your username and password.");
            }
        });

        vbox.getChildren().addAll(usernameField, passwordField, loginButton);
        Scene scene = new Scene(vbox, 300, 200);
        dialog.setScene(scene);
        dialog.showAndWait();

        return conn;  // Return the connection
    }

    private static Connection connectToDatabase(String username, String password) {
        try {
            String url = "jdbc:sqlserver://postsql.mandela.ac.za\\WRR;database=WRAP301Music";
            Connection conn = DriverManager.getConnection(url, username, password);
            return conn;  // Return the connection if successful
        } catch (SQLException e) {
            return null;  // Return null if the connection fails
        }
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR, message, ButtonType.OK);
        alert.setTitle(title);
        alert.showAndWait();
    }
}