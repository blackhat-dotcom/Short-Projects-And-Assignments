import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ButtonType;

import java.sql.*;
import java.util.*;

public class Main extends Application {

    private Connection conn;
    private ListView<Album> albumListView = new ListView<>();
    private TableView<Song> songTableView = new TableView<>();
    private TextField searchAlbumField = new TextField();
    private TextField searchSongField = new TextField();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Login Dialog
        conn = LoginDialog.showLoginDialog();  // Get the connection from LoginDialog
        if (conn == null) {
            return;  // Exit if connection fails
        }
        setupSongTable();
        // Layout Setup
        BorderPane root = new BorderPane();
        HBox searchBox = new HBox(10, searchAlbumField, searchSongField);
        Button searchAlbumButton = new Button("Search Albums");
        Button searchSongButton = new Button("Search Songs");

        searchAlbumButton.setOnAction(e -> searchAlbums());
        searchSongButton.setOnAction(e -> searchSongs());

        searchBox.getChildren().addAll(searchAlbumButton, searchSongButton);

        // Buttons for Add, Edit, Delete Operations
        Button addAlbumButton = new Button("Add Album");
        Button editAlbumButton = new Button("Edit Album");
        Button deleteAlbumButton = new Button("Delete Album");
        Button addSongButton = new Button("Add Song");
        Button editSongButton = new Button("Edit Song");
        Button deleteSongButton = new Button("Delete Song");

        addAlbumButton.setOnAction(e -> addAlbum());
        editAlbumButton.setOnAction(e -> editAlbum());
        deleteAlbumButton.setOnAction(e -> deleteAlbum());
        addSongButton.setOnAction(e -> addSong());
        editSongButton.setOnAction(e -> editSong());
        deleteSongButton.setOnAction(e -> deleteSong());

        // Layout for Buttons
        HBox albumButtons = new HBox(10, addAlbumButton, editAlbumButton, deleteAlbumButton);
        HBox songButtons = new HBox(10, addSongButton, editSongButton, deleteSongButton);

        root.setTop(searchBox);
        root.setLeft(albumListView);
        root.setCenter(songTableView);
        root.setBottom(new HBox(10, albumButtons, songButtons));

        loadAlbums();

        // Add listener for album selection
        albumListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                loadSongsForAlbum(newValue);  // Load songs for the selected album
            }
        });

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setTitle("Music Database");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private void loadAlbums() {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Album");
            List<Album> albums = new ArrayList<>();

            while (rs.next()) {
                int albumId = rs.getInt("AID");                  // Corrected
                String albumName = rs.getString("Title");        // Corrected
                String artist = "Unknown";                       // Placeholder, since 'Artist' is not in table
                int releaseYear = rs.getInt("Year");             // Corrected

                albums.add(new Album(albumId, albumName, artist, releaseYear));
            }

            ObservableList<Album> albumList = FXCollections.observableArrayList(albums);
            albumListView.setItems(albumList);

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Error loading albums: " + e.getMessage());
        }
    }
    private void setupSongTable() {
        TableColumn<Song, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));

        TableColumn<Song, String> artistCol = new TableColumn<>("Artist");
        artistCol.setCellValueFactory(new PropertyValueFactory<>("artist"));

        TableColumn<Song, Integer> songNoCol = new TableColumn<>("Song No");
        songNoCol.setCellValueFactory(new PropertyValueFactory<>("songNo"));

        TableColumn<Song, Integer> lengthCol = new TableColumn<>("Length");
        lengthCol.setCellValueFactory(new PropertyValueFactory<>("length"));

        songTableView.getColumns().addAll(titleCol, artistCol, songNoCol, lengthCol);
    }
    private void loadSongsForAlbum(Album album) {
        if (album == null) return;

        try {
            String query = "SELECT * FROM Song WHERE AID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, album.getAlbumId());
            ResultSet rs = stmt.executeQuery();

            List<Song> songs = new ArrayList<>();
            while (rs.next()) {
                int songId = rs.getInt("SID");
                String title = rs.getString("Title");
                String artist = rs.getString("Artist");
                int songNo = rs.getInt("SongNo");
                int length = rs.getInt("Length");

                songs.add(new Song(songId, title, artist, songNo, length));
            }

            // Update the TableView with songs of the selected album
            songTableView.setItems(FXCollections.observableArrayList(songs));
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Error loading songs: " + e.getMessage());
        }
    }

    private void searchAlbums() {
        String searchTerm = searchAlbumField.getText().trim().toLowerCase();
        try {
            String query = "SELECT * FROM Album WHERE LOWER(Title) LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + searchTerm + "%");
            ResultSet rs = stmt.executeQuery();

            List<Album> albums = new ArrayList<>();
            while (rs.next()) {
                int albumId = rs.getInt("AID");
                String albumName = rs.getString("Title");
                String artist = "Unknown";
                int releaseYear = rs.getInt("Year");

                albums.add(new Album(albumId, albumName, artist, releaseYear));
            }

            albumListView.setItems(FXCollections.observableArrayList(albums));
        } catch (SQLException e) {
            showAlert("Error", "Error searching albums: " + e.getMessage());
        }
    }

    private void searchSongs() {
        String searchTerm = searchSongField.getText().trim().toLowerCase();
        try {
            String query = "SELECT * FROM Song WHERE LOWER(Title) LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + searchTerm + "%");
            ResultSet rs = stmt.executeQuery();

            List<Song> songs = new ArrayList<>();
            while (rs.next()) {
                int songId = rs.getInt("SID");
                String title = rs.getString("Title");
                String artist = rs.getString("Artist");
                int songNo = rs.getInt("SongNo");
                int length = rs.getInt("Length");

                songs.add(new Song(songId, title, artist, songNo, length));
            }

            songTableView.setItems(FXCollections.observableArrayList(songs));
        } catch (SQLException e) {
            showAlert("Error", "Error searching songs: " + e.getMessage());
        }
    }

    // Add Album
    private void addAlbum() {
        // Create input fields
        TextInputDialog titleDialog = new TextInputDialog();
        titleDialog.setTitle("Add Album");
        titleDialog.setHeaderText("Enter album title:");
        Optional<String> titleResult = titleDialog.showAndWait();

        if (titleResult.isEmpty()) return;
        String albumTitle = titleResult.get().trim();
        if (albumTitle.isEmpty()) {
            showAlert("Input Error", "Album title cannot be empty.");
            return;
        }

        TextInputDialog yearDialog = new TextInputDialog();
        yearDialog.setTitle("Add Album");
        yearDialog.setHeaderText("Enter album release year:");
        Optional<String> yearResult = yearDialog.showAndWait();

        if (yearResult.isEmpty()) return;
        int releaseYear;
        try {
            releaseYear = Integer.parseInt(yearResult.get().trim());
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Invalid year format.");
            return;
        }

        // Insert into DB
        try {
            String albumQuery = "INSERT INTO Album (Title, Year) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(albumQuery);
            stmt.setString(1, albumTitle);
            stmt.setInt(2, releaseYear);
            stmt.executeUpdate();
            loadAlbums();  // Reload the album list
        } catch (SQLException e) {
            showAlert("Error", "Error adding album: " + e.getMessage());
        }
    }

    // Edit Album
    private void editAlbum() {
        Album selectedAlbum = albumListView.getSelectionModel().getSelectedItem();
        if (selectedAlbum == null) {
            showAlert("Error", "No album selected.");
            return;
        }

        // Prompt for new album title
        TextInputDialog dialog = new TextInputDialog(selectedAlbum.getAlbumName()); // use the title as default
        dialog.setTitle("Edit Album");
        dialog.setHeaderText("Edit album details");

        dialog.showAndWait().ifPresent(newAlbumTitle -> {
            try {
                // Update the album title in the database
                String query = "UPDATE Album SET Title = ? WHERE AID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, newAlbumTitle);  // Update title
                stmt.setInt(2, selectedAlbum.getAlbumId());  // Match the album by AID
                stmt.executeUpdate();
                loadAlbums();  // Reload albums to reflect changes
            } catch (SQLException e) {
                showAlert("Error", "Error editing album: " + e.getMessage());
            }
        });
    }

    // Delete Album
    private void deleteAlbum() {
        Album selectedAlbum = albumListView.getSelectionModel().getSelectedItem();
        if (selectedAlbum == null) {
            showAlert("Error", "No album selected.");
            return;
        }

        // Confirm delete
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Delete Album");
        alert.setHeaderText("Are you sure you want to delete this album?");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    // Correcting the column name to 'AID'
                    String query = "DELETE FROM Album WHERE AID = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, selectedAlbum.getAlbumId());  // Ensure 'getAlbumId()' corresponds to 'AID'
                    stmt.executeUpdate();
                    loadAlbums();  // Reload albums after deletion
                } catch (SQLException e) {
                    showAlert("Error", "Error deleting album: " + e.getMessage());
                }
            }
        });
    }
    // Add Song
    private void addSong() {
        // Ensure an album is selected first
        Album selectedAlbum = albumListView.getSelectionModel().getSelectedItem();
        if (selectedAlbum == null) {
            showAlert("Error", "Please select an album first.");
            return;
        }

        // Prompt for song title
        TextInputDialog titleDialog = new TextInputDialog();
        titleDialog.setHeaderText("Enter song title:");
        Optional<String> titleResult = titleDialog.showAndWait();
        if (titleResult.isEmpty()) return;

        String title = titleResult.get().trim();
        if (title.isEmpty()) {
            showAlert("Input Error", "Song title cannot be empty.");
            return;
        }

        // Prompt for song number
        TextInputDialog songNoDialog = new TextInputDialog();
        songNoDialog.setHeaderText("Enter song number:");
        Optional<String> songNoResult = songNoDialog.showAndWait();
        if (songNoResult.isEmpty()) return;

        int songNo;
        try {
            songNo = Integer.parseInt(songNoResult.get().trim());
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Invalid song number.");
            return;
        }

        // Prompt for song length
        TextInputDialog lengthDialog = new TextInputDialog();
        lengthDialog.setHeaderText("Enter song length (in seconds):");
        Optional<String> lengthResult = lengthDialog.showAndWait();
        if (lengthResult.isEmpty()) return;

        int length;
        try {
            length = Integer.parseInt(lengthResult.get().trim());
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Invalid length format.");
            return;
        }

        // Prompt for artist name
        TextInputDialog artistDialog = new TextInputDialog();
        artistDialog.setHeaderText("Enter artist name:");
        Optional<String> artistResult = artistDialog.showAndWait();
        if (artistResult.isEmpty()) return;

        String artist = artistResult.get().trim();
        if (artist.isEmpty()) {
            showAlert("Input Error", "Artist name cannot be empty.");
            return;
        }

        // Now insert the song into the database with the provided details
        try {
            String query = "INSERT INTO Song (Title, AID, SongNo, Length, Artist) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, title);              // Set song title
            stmt.setInt(2, selectedAlbum.getAlbumId()); // Set album ID
            stmt.setInt(3, songNo);                // Set song number
            stmt.setInt(4, length);                // Set song length
            stmt.setString(5, artist);             // Set artist name

            stmt.executeUpdate();
            loadSongsForAlbum(selectedAlbum); // Reload songs for selected album
        } catch (SQLException e) {
            showAlert("Error", "Could not add song: " + e.getMessage());
        }
    }

    private void editSong() {
        Song selectedSong = songTableView.getSelectionModel().getSelectedItem();
        if (selectedSong == null) {
            showAlert("Error", "Please select a song to edit.");
            return;
        }

        TextInputDialog titleDialog = new TextInputDialog(selectedSong.getTitle());
        titleDialog.setHeaderText("Edit song title:");
        titleDialog.showAndWait().ifPresent(newTitle -> {
            if (newTitle.trim().isEmpty()) {
                showAlert("Input Error", "Title cannot be empty.");
                return;
            }

            try {
                PreparedStatement stmt = conn.prepareStatement("UPDATE Song SET Title = ? WHERE SID = ?");
                stmt.setString(1, newTitle.trim());
                stmt.setInt(2, selectedSong.getSongId());
                stmt.executeUpdate();
                Album selectedAlbum = albumListView.getSelectionModel().getSelectedItem();
                loadSongsForAlbum(selectedAlbum);
            } catch (SQLException e) {
                showAlert("Error", "Could not edit song: " + e.getMessage());
            }
        });
    }

    private void deleteSong() {
        Song selectedSong = songTableView.getSelectionModel().getSelectedItem();
        if (selectedSong == null) {
            showAlert("Error", "Please select a song to delete.");
            return;
        }

        Alert alert = new Alert(AlertType.CONFIRMATION, "Are you sure you want to delete this song?", ButtonType.YES, ButtonType.NO);
        alert.setTitle("Delete Song");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try {
                    PreparedStatement stmt = conn.prepareStatement("DELETE FROM Song WHERE SID = ?");
                    stmt.setInt(1, selectedSong.getSongId());
                    stmt.executeUpdate();
                    Album selectedAlbum = albumListView.getSelectionModel().getSelectedItem();
                    loadSongsForAlbum(selectedAlbum);
                } catch (SQLException e) {
                    showAlert("Error", "Could not delete song: " + e.getMessage());
                }
            }
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
