public class Album {
    private int albumId;
    private String albumName;
    private String artist;
    private int releaseYear;

    // Constructor to initialize Album
    public Album(int albumId, String albumName, String artist, int releaseYear) {
        this.albumId = albumId;
        this.albumName = albumName;
        this.artist = artist;
        this.releaseYear = releaseYear;
    }

    // Getter and Setter methods
    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    // toString method for displaying album information (useful for ListView)
    @Override
    public String toString() {
        return albumName + " (" + releaseYear + ") - " + artist;
    }
}