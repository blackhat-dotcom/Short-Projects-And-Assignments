import java.sql.*;
import java.util.Scanner;

public class Main {
    private static Connection conn;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        connectToDatabase();
        if (conn != null) {
            displayMenu();
        }
    }

    private static void connectToDatabase() {
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        try {
            // Connection string for SQL Server
            String url = "jdbc:sqlserver://postsql.mandela.ac.za\\WRR;database=WRAP301Music";
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Connection established successfully.");
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
            conn = null;
        }
    }

    private static void displayMenu() {
        while (true) {
            System.out.println("\nMusic Database Menu:");
            System.out.println("1. Create a new Album and Add Songs");
            System.out.println("2. Edit an Existing Album or Song");
            System.out.println("3. Query Songs by Artist");
            System.out.println("4. Query Songs by Title Phrase");
            System.out.println("5. Query Albums by Title Phrase");
            System.out.println("6. Exit");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
                case 1:
                    createAlbumAndSongs();
                    break;
                case 2:
                    editAlbumOrSong();
                    break;
                case 3:
                    querySongsByArtist();
                    break;
                case 4:
                    querySongsByTitlePhrase();
                    break;
                case 5:
                    queryAlbumsByTitlePhrase();
                    break;
                case 6:
                    disconnectFromDatabase();
                    return;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }

    private static void createAlbumAndSongs() {
        System.out.print("Enter album name: ");
        String albumName = scanner.nextLine();
        System.out.print("Enter artist name: ");
        String artist = scanner.nextLine();
        System.out.print("Enter release year: ");
        int releaseYear = scanner.nextInt();
        scanner.nextLine();  // consume newline

        try {
            String albumQuery = "INSERT INTO Album (AlbumName, Artist, ReleaseYear) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(albumQuery, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, albumName);
            stmt.setString(2, artist);
            stmt.setInt(3, releaseYear);
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int albumId = generatedKeys.getInt(1);
                    System.out.println("Album created with ID: " + albumId);

                    // Add songs
                    while (true) {
                        System.out.print("Enter song title (or type 'done' to finish): ");
                        String songTitle = scanner.nextLine();
                        if (songTitle.equalsIgnoreCase("done")) {
                            break;
                        }
                        System.out.print("Enter song artist: ");
                        String songArtist = scanner.nextLine();

                        String songQuery = "INSERT INTO Song (Title, Artist, AlbumId) VALUES (?, ?, ?)";
                        PreparedStatement songStmt = conn.prepareStatement(songQuery);
                        songStmt.setString(1, songTitle);
                        songStmt.setString(2, songArtist);
                        songStmt.setInt(3, albumId);
                        songStmt.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error creating album: " + e.getMessage());
        }
    }

    private static void editAlbumOrSong() {
        System.out.println("1. Edit an Album");
        System.out.println("2. Edit a Song");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (choice == 1) {
            editAlbum();
        } else if (choice == 2) {
            editSong();
        } else {
            System.out.println("Invalid option.");
        }
    }

    private static void editAlbum() {
        System.out.print("Enter the album ID to edit: ");
        int albumId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.print("Enter new album name: ");
        String albumName = scanner.nextLine();
        System.out.print("Enter new artist name: ");
        String artist = scanner.nextLine();
        System.out.print("Enter new release year: ");
        int releaseYear = scanner.nextInt();
        scanner.nextLine(); // consume newline

        try {
            String updateQuery = "UPDATE Album SET AlbumName = ?, Artist = ?, ReleaseYear = ? WHERE AlbumId = ?";
            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            stmt.setString(1, albumName);
            stmt.setString(2, artist);
            stmt.setInt(3, releaseYear);
            stmt.setInt(4, albumId);
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Album updated successfully.");
            } else {
                System.out.println("Album not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error editing album: " + e.getMessage());
        }
    }

    private static void editSong() {
        System.out.print("Enter the song ID to edit: ");
        int songId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.print("Enter new song title: ");
        String songTitle = scanner.nextLine();
        System.out.print("Enter new song artist: ");
        String songArtist = scanner.nextLine();

        try {
            String updateQuery = "UPDATE Song SET Title = ?, Artist = ? WHERE SongId = ?";
            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            stmt.setString(1, songTitle);
            stmt.setString(2, songArtist);
            stmt.setInt(3, songId);
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Song updated successfully.");
            } else {
                System.out.println("Song not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error editing song: " + e.getMessage());
        }
    }

    private static void querySongsByArtist() {
        System.out.print("Enter artist name to search: ");
        String artist = scanner.nextLine();

        try {
            String query = "SELECT Song.Title, Album.AlbumName FROM Song JOIN Album ON Song.AlbumId = Album.AlbumId WHERE Song.Artist = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, artist);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String songTitle = rs.getString("Title");
                String albumName = rs.getString("AlbumName");
                System.out.println(songTitle + " (Album: " + albumName + ")");
            }
        } catch (SQLException e) {
            System.out.println("Error querying songs by artist: " + e.getMessage());
        }
    }

    private static void querySongsByTitlePhrase() {
        System.out.print("Enter phrase to search in song title: ");
        String phrase = scanner.nextLine();

        try {
            String query = "SELECT Song.Title, Album.AlbumName FROM Song JOIN Album ON Song.AlbumId = Album.AlbumId WHERE Song.Title LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + phrase + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String songTitle = rs.getString("Title");
                String albumName = rs.getString("AlbumName");
                System.out.println(songTitle + " (Album: " + albumName + ")");
            }
        } catch (SQLException e) {
            System.out.println("Error querying songs by title: " + e.getMessage());
        }
    }

    private static void queryAlbumsByTitlePhrase() {
        System.out.print("Enter phrase to search in album title: ");
        String phrase = scanner.nextLine();

        try {
            String query = "SELECT AlbumName FROM Album WHERE AlbumName LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + phrase + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String albumName = rs.getString("AlbumName");
                System.out.println(albumName);
            }
        } catch (SQLException e) {
            System.out.println("Error querying albums by title: " + e.getMessage());
        }
    }

    private static void disconnectFromDatabase() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Disconnected from the database.");
            }
        } catch (SQLException e) {
            System.out.println("Error disconnecting: " + e.getMessage());
        }
    }
}