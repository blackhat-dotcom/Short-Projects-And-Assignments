import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        try {
            // Load the XML file (adjust the path as needed)
            File xmlFile = new File("C:\\Users\\sandi\\Downloads\\hamlet.xml");
            System.out.println("XML File path: " + xmlFile.getAbsolutePath());

            // Parse the document
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = docBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(xmlFile);
            document.getDocumentElement().normalize();

            // Get all the <PERSONAE> section(s)
            NodeList personaeList = document.getElementsByTagName("PERSONAE");
            List<String> personaNames = new ArrayList<>();

            // Collect all the persona names from the <PERSONAE> section
            for (int i = 0; i < personaeList.getLength(); i++) {
                Element personae = (Element) personaeList.item(i);
                NodeList personaList = personae.getElementsByTagName("PERSONA");

                for (int j = 0; j < personaList.getLength(); j++) {
                    Element persona = (Element) personaList.item(j);
                    String personaName = persona.getTextContent().trim().toLowerCase();  // Normalize case and trim spaces
                    personaNames.add(personaName);
                    System.out.println("Found persona: " + personaName); // Debugging: print persona names
                }
            }

            // Ask for a persona name (input from user)
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter persona name (e.g., Hamlet): ");
            String inputPersonaName = scanner.nextLine().trim().toLowerCase();  // Normalize user input

            // Check if the input persona name exists
            if (!personaNames.contains(inputPersonaName)) {
                System.out.println("Invalid persona name.");
                return;
            }

            // List to hold speeches by the persona
            List<String> speeches = new ArrayList<>();

            // Get all the acts and scenes and extract speeches by the persona
            NodeList acts = document.getElementsByTagName("ACT");
            for (int i = 0; i < acts.getLength(); i++) {
                Element act = (Element) acts.item(i);
                String actTitle = getTitle(act); // Extract act title
                System.out.println("Processing Act: " + actTitle); // Debugging: print act title

                NodeList scenes = act.getElementsByTagName("SCENE");
                for (int j = 0; j < scenes.getLength(); j++) {
                    Element scene = (Element) scenes.item(j);
                    String sceneTitle = getTitle(scene); // Extract scene title
                    System.out.println("Processing Scene: " + sceneTitle); // Debugging: print scene title

                    NodeList speechesInScene = scene.getElementsByTagName("SPEECH");
                    for (int k = 0; k < speechesInScene.getLength(); k++) {
                        Element speech = (Element) speechesInScene.item(k);
                        NodeList speakerList = speech.getElementsByTagName("SPEAKER");

                        for (int m = 0; m < speakerList.getLength(); m++) {
                            String speakerName = speakerList.item(m).getTextContent().trim().toLowerCase(); // Normalize speaker name
                            System.out.println("Found speaker: " + speakerName); // Debugging: print speaker name

                            if (speakerName.equals(inputPersonaName)) {
                                // Collect the lines of the speech
                                NodeList lines = speech.getElementsByTagName("LINE");
                                StringBuilder speechText = new StringBuilder();
                                for (int n = 0; n < lines.getLength(); n++) {
                                    speechText.append(lines.item(n).getTextContent().trim()).append("\n");
                                }

                                // Format and add the speech to the list
                                speeches.add("Act: " + actTitle + ", Scene: " + sceneTitle + "\n" + speechText.toString());
                            }
                        }
                    }
                }
            }

            // Print all collected speeches
            if (!speeches.isEmpty()) {
                System.out.println("\nSpeeches by " + inputPersonaName + ":\n");
                for (String speech : speeches) {
                    System.out.println(speech);
                    System.out.println("-----");
                }
            } else {
                System.out.println("No speeches found for " + inputPersonaName);
            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
    }

    // Helper method to extract the title of a given element (Act or Scene)
    private static String getTitle(Element element) {
        NodeList titleList = element.getElementsByTagName("TITLE");
        if (titleList.getLength() > 0) {
            return titleList.item(0).getTextContent().trim();
        }
        return "UNKNOWN";
    }
}