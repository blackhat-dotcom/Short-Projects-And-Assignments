package nmmu.wrap301;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            // Specify the correct path to your menu.xml file here
            File xmlFile = new File("C:\\Users\\sandi\\Downloads\\A3T2Code\\A3T2Code\\resources\\menu.xml");

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);
            Element root = document.getDocumentElement();

            // Step 1: Load the controller class and create an instance
            String controllerClassName = root.getAttribute("controller");
            Class<?> controllerClass = Class.forName(controllerClassName);
            Object controller = controllerClass.getDeclaredConstructor().newInstance();  // ✅ Correct constructor access

            // Step 2: Create Menu with title
            String menuTitle = root.getAttribute("title");
            nmmu.wrap301.menu.Menu menu = new nmmu.wrap301.menu.Menu(menuTitle);

            // Step 3: Parse the XML and handle choices and submenus
            parseMenuNodes(root, controllerClass, controller, menu);

            // Step 4: Run the menu
            menu.run();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void parseMenuNodes(Element parentElement, Class<?> controllerClass, Object controller, nmmu.wrap301.menu.Menu menu) throws Exception {
        NodeList children = parentElement.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;

                if ("choice".equals(element.getNodeName())) {
                    // Handle menu choices
                    String text = element.getAttribute("text");
                    String methodName = element.getAttribute("method");

                    // Use reflection to find the method
                    Method method = controllerClass.getMethod(methodName);

                    // Create the Runnable action for this choice
                    Runnable action = () -> {
                        try {
                            method.invoke(controller);  // Invoke the method
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    };

                    // Add choice to the menu
                    menu.add(text, action);
                } else if ("submenu".equals(element.getNodeName())) {
                    // Handle submenus
                    String subMenuTitle = element.getAttribute("title");
                    nmmu.wrap301.menu.Menu subMenu = new nmmu.wrap301.menu.Menu(subMenuTitle);

                    // Recursively parse submenu items
                    parseMenuNodes(element, controllerClass, controller, subMenu);

                    // Add submenu to the main menu
                    String subMenuText = element.getAttribute("text");
                    Runnable submenuAction = subMenu::run;
                    menu.add(subMenuText, submenuAction);
                }
            }
        }
    }
}